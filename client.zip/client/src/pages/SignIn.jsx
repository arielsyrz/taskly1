//signin.jsx
export default function Signin(){
    return <h1>Sign in</h1>
}