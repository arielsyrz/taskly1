import { Box, Heading, Button } from "@chakra-ui/react";

export default function Home() {
  return (
    <Box bg="teal.100" minHeight="100vh" display="flex" justifyContent="center" alignItems="center">
      <Heading color="teal.800">Home</Heading>
      <Button colorScheme="teal" mt={4}>Click Me</Button>
    </Box>
  );
}
