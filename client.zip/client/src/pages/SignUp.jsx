//signup.jsx
export default function Signup(){
    return <h1>signup</h1>
}